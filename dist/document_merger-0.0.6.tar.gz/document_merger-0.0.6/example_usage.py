# from document_merger import DocumentMerger, DocumentMergerConfig

from src.document_merger import DocumentMerger, DocumentMergerConfig

import os

user_path = os.path.expanduser("~\\")


document_merger_config = DocumentMergerConfig(
    analysis_path=f"{user_path}OneDrive\\Homework\\2024",
    temp_file_path=f"{user_path}Downloads\\document-merger",
    cache_file_path=f"{user_path}Downloads\\document-merger\\document_merger_cache.json",
    # image_output_path=f"{user_path}Downloads\\document-merger\\images",
    tesseract_path="C:\\Program files\\Tesseract-OCR\\tesseract.exe",
    ignored_dirs=(
        "Textbooks",
        "temp",
        "__pycache__",
        "Assignment 1",
        "Assessment 1",
        "Assignment 2",
        "Assessment 2",
        "Algorithms and Analysis",
        "Full stack development",
        "Introduction to Cybersecurity",
        "Software engineering fundamentals",
        "Software Engineering Process and Tools",
        # "Software Requirements Engineering",
        "Systems Architecture and Design",
        "Software Testing",
    ),
    main_output_type="html",
    keep_temp_files=True,
    show_image=False,
    print_status_table=True,
    create_imageless_version=True,
    process_subdirectories_individually=True,
    absolute_temp_directory_names=True,
)

# document_merger_config = DocumentMergerConfig(
#     analysis_path=f"C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Systems Architecture and Design\\20092024",
#     temp_file_path=f"{user_path}Downloads\\document-merger",
#     cache_file_path=f"{user_path}Downloads\\document-merger\\document_merger_cache.json",
#     # image_output_path=f"{user_path}Downloads\\document-merger\\images",
#     tesseract_path="C:\\Program files\\Tesseract-OCR\\tesseract.exe",
#     ignored_dirs=(
#         "Textbooks",
#         "temp",
#         "__pycache__",
#         "Assignment 1",
#         "Assessment 1",
#         "Assignment 2",
#         "Assessment 2",
#         "Algorithms and Analysis",
#         "Full stack development",
#         "Introduction to Cybersecurity",
#         "Software engineering fundamentals",
#         "Software Engineering Process and Tools",
#         "Software Requirements Engineering",
#     ),
#     main_output_type="html",
#     keep_temp_files=True,
#     show_image=False,
#     print_status_table=True,
#     create_imageless_version=True,
#     process_subdirectories_individually=False,
#     absolute_temp_directory_names=True,
# )

DocumentMerger(document_merger_config).start()
