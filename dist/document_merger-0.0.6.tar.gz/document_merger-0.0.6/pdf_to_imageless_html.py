import sys
import os

# from document_merger import Converter, DocumentMergerConfig
from src.document_merger import Converter, DocumentMergerConfig

import re


def check_exists(file):
    if not os.path.exists(file):
        print(f"ERROR: Path '{file}' does not exist")
        exit()


if __name__ == "__main__":
    # if len(sys.argv) != 3:
    #     print("ERROR: Invalid number of arguments")
    #     exit()
    # in_path = sys.argv[1]
    # out_path = sys.argv[2]

    in_path = "C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Textbooks\\ST\\Erik van Veenendaal_ Dorothy Graham_ Rex Black - Foundations of Software Testing_ ISTQB Certification-Cengage Learning EMEA (2019).pdf"
    out_path = (
        "C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Software Testing\\textbook.html"
    )
    imageless_path = "C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Software Testing\\textbook imageless.html"

    check_exists(in_path)
    # temp_path = f"(TEMP) {out_path.split("\\")[-1]}"

    user_path = os.path.expanduser("~\\")
    c = Converter(
        config=DocumentMergerConfig(
            analysis_path=f"{user_path}OneDrive\\Homework\\2024",
            temp_file_path=f"{user_path}Downloads\\document-merger",
            cache_file_path=f"{user_path}Downloads\\document-merger\\document_merger_cache.json",
            tesseract_path="C:\\Program files\\Tesseract-OCR\\tesseract.exe",
        )
    )
    c.PDF_to_HTML(in_path, out_path)

    with open(imageless_path, "w", encoding="utf8") as f:
        with open(
            out_path,
            "r",
            encoding="utf8",
            errors="ignore",
        ) as existing_html:
            f.write(
                re.sub(
                    r'<img src=".*?base64, ?[^"]*"[^>]*>',
                    "",
                    existing_html.read(),
                )
            )
    os.remove(out_path)
