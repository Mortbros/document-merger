from doctr.io import DocumentFile
from doctr.models import ocr_predictor
import time

print("-------------------start")
start = time.time()
model = ocr_predictor(pretrained=True)
print("-------------------model")
# PDF
doc = DocumentFile.from_pdf(
    "C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Textbooks\\ST\\Erik van Veenendaal_ Dorothy Graham_ Rex Black - Foundations of Software Testing_ ISTQB Certification-Cengage Learning EMEA (2019).pdf"
)
print("-------------------doc")
# Analyze
result = model(doc)
print("-------------------result")


with open("DELETE TEMP.txt", "w") as f:
    f.write(result)
print(result)
print(f"program took {time.time() - start} seconds to run")
